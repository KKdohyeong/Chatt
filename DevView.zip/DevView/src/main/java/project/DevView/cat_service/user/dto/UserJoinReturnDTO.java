package project.DevView.cat_service.user.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserJoinReturnDTO {
    private String username;
    private String password;
}
